package game;

public class Myskill {
    protected int type,maxmulti,minmulti,cost,pattern,state,proc,special,limit;// if state !=0 set proc
    String name,description;
}
