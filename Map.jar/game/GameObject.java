package game;

import org.newdawn.slick.Graphics;

public interface GameObject{
    public void render(Graphics g);
}
